# 機能
- ServiceWorkerを用いたオフラインでも利用可能な学習ドリル

# 使い方
- 必要な事項を記載したmanifest.jsonを、base64でエンコードしてindex.htmlに記述
- AnytimeDrillの公開URLを、main.js、drill.js、random-drill.jsのdrillUrlに記述

# 前提条件 / 注意事項
