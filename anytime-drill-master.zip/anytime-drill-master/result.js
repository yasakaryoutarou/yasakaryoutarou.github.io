//解答結果の表示
var answer ='';
var correctanswer = 0; 

for(var i=1;i<=6;i++){
    var temp = localStorage.getItem(i);
    //正解数カウント
    if(temp == "○"){
        correctanswer++;
    }
    answer += '問題' + i + "　" + temp + '　　';
}

var result = document.getElementById("res"); 
    result.innerHTML = answer;
var result = document.getElementById("corans"); 
    result.innerHTML = "正解数　" + correctanswer ;
