var CACHE_NAME = 'cache-v1';
var urlsToCache = [
    'index.html',
    'main.js',
    'selection.html',
    'drill.html',
    'drill.js',
    'random-drill.html',
    'random-drill.js',
    'result.html',
    'result.js',
    'drills/kihonnjouhou30.json',
    'drills/fe30-2.png',
    'drills/fe30-4.png',
    'drills/fe30-5a.png',
    'drills/fe30-5e.png',
    'drills/fe30-5i.png',
    'drills/fe30-5u.png',
    'drills/fe30-30.png'
];

self.addEventListener('install', function(event){
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(function(cache) {
                return Promise.all(
                    urlsToCache.map(function(url) {
                        return fetch(new Request(url, {cache: 'no-cache'}))
                            .then(function(response) {
                                return cache.put(url, response);
                        });
                    })
                );
            })
    );
});


self.addEventListener('fetch', function(event) {
    //urlパラメータありの処理
    var hatena = event.request.url;
    var newurl = "";
    var flag=0;
    console.log(hatena);
    for(var i=0;i<hatena.length;i++){
        if(hatena[i] == "?"){
            flag=1;
            break;
        }
        newurl+=hatena[i];
        console.log(newurl);
    }
    if(flag == 1){
        event.respondWith(
            caches.match(newurl)
                .then(function(response) {
                    return response || fetch(event.request);
                })
        );
    }
    
    //通常
    event.respondWith(
        caches.match(event.request)
            .then(function(response) {
                return response || fetch(event.request);
                
            })
    );
});

//新しいServiceWorkerを動作させる
self.addEventListener('message', function(event) {
   if(event.data.action === 'skipWaiting'){
       self.skipWaiting();
   } 
});
