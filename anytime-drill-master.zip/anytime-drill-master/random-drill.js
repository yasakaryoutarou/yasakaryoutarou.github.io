//urlパラメータ取得
var params = new URLSearchParams(document.location.search.substring(1));
var questionName = params.get("qname");

//JSONの取得
var drillData;

//出題順序をランダムするための配列
var barabara = [];

// ドリルURLの指定
var drillUrl = 'https://.../'

//myJsonにjsonが返ってくる
fetch(drillUrl + 'drills/' + questionName +'.json')
    .then(function(response) {
        return response.json();
    }).then(function(myJson) {
        drillData=myJson;

        //Fisher–Yatesアルゴリズム
        var n = drillData.drill.length;
        
        //配列用意
        for(var g = 0;g < n;g++){
            barabara[g] = g;
        }

        for(var i = n - 1; i > 0; i--) {
            var j = Math.floor(Math.random() * (i + 1));
            var tmp = barabara[i];
            barabara[i] = barabara[j];
            barabara[j] = tmp;
        }
});

//問題の位置
var stage = 0;

//更新位置をidで取得
var number = document.getElementById("questionNumber"); 
var question = document.getElementById("questionArea"); 
var image = document.getElementById("imageArea"); 
var choicea = document.getElementById("a"); 
var choicei = document.getElementById("i");
var choiceu = document.getElementById("u"); 
var choicee = document.getElementById("e"); 
var answer = document.getElementById("answerArea"); 
var versionA = document.getElementById("versionArea");

//選択肢配列
var sentaku = ["ア","イ","ウ","エ"];

var count = 0;

//解答を始めるをクリック
function start(){
    number.innerHTML = "問題　"　+ (stage+1);
    question.innerHTML = drillData.drill[barabara[stage]].question;
    image.innerHTML = drillData.drill[barabara[stage]].image;
    choicea.innerHTML = drillData.drill[barabara[stage]].choices[0];
    choicei.innerHTML = drillData.drill[barabara[stage]].choices[1];
    choiceu.innerHTML = drillData.drill[barabara[stage]].choices[2];
    choicee.innerHTML = drillData.drill[barabara[stage]].choices[3];

    //表示
    var show = document.getElementById("showArea"); 
    show.style.display = "";
}

//解答の正誤判定
function judge(selectAnswer){
    var TF = "";

    if(selectAnswer === drillData.drill[barabara[stage]].answer){
        TF = "○";
    }else{
        TF = "×";
    }

    count++;
    
    if(count == 1){
        localStorage.setItem((stage+1),TF);
    }

    answer.innerHTML = TF + "　正解　" + sentaku[drillData.drill[barabara[stage]].answer];
}

//次の問題へをクリック
function nextQuestion(){

    stage++;
    count = 0;

    number.innerHTML = "問題　" + (stage+1);
    question.innerHTML = drillData.drill[barabara[stage]].question;
    image.innerHTML = drillData.drill[barabara[stage]].image;
    choicea.innerHTML = drillData.drill[barabara[stage]].choices[0];
    choicei.innerHTML = drillData.drill[barabara[stage]].choices[1];
    choiceu.innerHTML = drillData.drill[barabara[stage]].choices[2];
    choicee.innerHTML = drillData.drill[barabara[stage]].choices[3];
    answer.innerHTML = "<input type='button' value ='ここに正解が表示される' >";

    //次の問題が最後の時
    if(stage+1 == drillData.drill.length){
        var next = document.getElementById("nextArea"); 
        next.innerHTML = "<a href = 'result.html' >結果画面へ</a>";
    }
}
