var newWorker;
var refreshing;
var nowDrillVersion;
var appVersion = document.getElementById('appVer');
var drillUrl = 'https://.../'

if (navigator.onLine){
    //オンライン時の処理
    fetch(drillUrl + 'manifest.json',{cache: "no-cache"})
        .then(function(response) {
            return response.json();
        }).then(function(maniJson) {
            nowDrillVersion=maniJson.drillVersion;
            appVersion.innerHTML="アプリバージョン:"+nowDrillVersion;
            
            console.log(JSON.stringify(maniJson));
            console.log(nowDrillVersion);
            
            //アプリのバージョンが保存されていなければ保存
            //アプリのバージョンの更新があれば更新メッセージ表示
            if ( !localStorage.getItem("verCheck")){
                localStorage.setItem("verCheck",nowDrillVersion);
                console.log(nowDrillVersion);
            }else if(localStorage.getItem("verCheck") != nowDrillVersion){
                let drillNotification = document.getElementById('drillNotification');
                drillNotification.style.display = '';
                localStorage.setItem("verCheck",nowDrillVersion);
            }
        }
    );
}else{
    //オフライン時の処理：保存されたアプリのバージョン表示
    nowDrillVersion = localStorage.getItem("verCheck");
    appVersion.innerHTML="アプリバージョン:"+nowDrillVersion;
}


//ServiceWorkerの登録
if ('serviceWorker' in navigator){
    navigator.serviceWorker.register(drillUrl + 'sw.js',{ scope: './' })
    .then(initialState)
    .catch(function(err){
        //登録失敗
        console.log('ServiceWorker registration failed: ', err);
    });
}

//ServiceWorkerの更新ボタンをクリック
document.getElementById('reload').addEventListener('click', function(){
    newWorker.postMessage({action: 'skipWaiting'});
});


//新しいServiceWorkerが動作
navigator.serviceWorker.addEventListener('controllerchange', function(){
   if(refreshing) return;
   window.location.reload();
   refreshing = true;
});

function initialState (registration) {
    //登録成功
    console.log('ServiceWorker registration successful with scope: ',registration.scope);
    console.log(registration);
    
    //アプリのバージョンの更新ボタンをクリック
    document.getElementById('newRegist').addEventListener('click', function(){
        registration.unregister().then(function(boolean) {
            //ServiceWorker登録解除成功
            if(boolean == true){ 
                console.log("unregister is successful");
                window.location.reload();
            }
        });
    });
        
    //ServiceWorkerの更新あり
    registration.addEventListener('updatefound', function(){
        //新しいServiceWorkerをインストール
        newWorker = registration.installing;
        
        newWorker.addEventListener('statechange', function(){
           switch (newWorker.state) {
               case 'installed':
                   //新しいServiceWorkerがインストールされたら
                   //更新メッセージ表示
                   if(navigator.serviceWorker.controller){
                       let notification = document.getElementById('notification');
                       notification.style.display = '';
                   }
                   break;
           } 
        });
    });
}